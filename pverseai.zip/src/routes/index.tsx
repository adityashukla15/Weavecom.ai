import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PanelVerse AI" },
      { name: "description", content: "PanelVerse AI — create comic panels and stories." },
      { property: "og:title", content: "PanelVerse AI" },
      { property: "og:description", content: "PanelVerse AI — create comic panels and stories." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <iframe
      src="/panelverse.html"
      title="PanelVerse AI"
      className="fixed inset-0 h-screen w-screen border-0"
    />
  );
}
